<?php


namespace SimpleEngine\Controller;


class AdminController extends PageController
{

    public function actionIndex()
    {
        if($this->getModel()->getUser()->isAdmin()){
            echo $this->render("index");
        }
        else{
            echo $this->render("error");
        }
        
    }

    public function actionEdit(){
        if($this->getModel()->getUser()->isAdmin()){
            echo $this->render("edit");
        }
        else{
            echo $this->render("error");
        }
    }

    public function getModelName()
    {
        return "Admin";
    }
}