<?php


namespace SimpleEngine\Controller;

use SimpleEngine\Model\Page;
use SimpleEngine\Model\Comment;
use SimpleEngine\Model\User;

class PageController extends BasicController
{
    protected $error_code;
    protected $error_text = "такой страницы не существует";
    

    public function __construct()
    {
        $this->model = Page::instance();
        $this->user = User::instance();
    }
    public  function __call($name, $arguments)
    {

        echo $this -> render('error');
    }

    // Выводит все статьи на главной
    public function actionIndex(){
     if($this->user->checkCookie()) $this->user->authorize();
     $articles = $this ->model->allPage();
    foreach ($articles as $k => $article ){

    $articles[$k]['content'] = $this -> model->articlesIntro($article,400);
    }
        echo $this->render("index", array('articles'=> $articles));
    }
    // Выводит одну статью и комментарии кней
    public function actionRead($id_article){
        $article = $this -> model -> getPage($id_article);
        if(!$article) echo $this ->render('error');
        $comments = Comment::instance()->allComments($id_article);
        $user_name = '';
        var_dump($this->user);
        /*if($this->user->isAuthorized()) $user_name */ echo 'name: '.$this->user->getName();
       echo $this -> render('article', array('article' => $article, 'comments'=>$comments,
                                            'is_login' => false, 'name'=>$user_name));
    }
    public function actionLogin (){

        echo $this -> render('login');
    }
    public function  actionAuthorize(){
        $authorized = $this ->user ->authorize();
        if( $authorized['ok']){
            header('Location: /');
        }
        else{
            echo $this ->render('error', array('error' => $authorized['error']));
        }
    }
    public function actionLogout (){

        $this->user->lodOut();
        $this -> actionIndex();
    }
    public function getModelName()
    {
        return "Page";
    }

    public function getError(){
        return $this->error_text;
    }
    public function getUser(){
        return $this -> user;
    }

}