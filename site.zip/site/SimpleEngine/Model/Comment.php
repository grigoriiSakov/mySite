<?php
//
// Менеджер комментариев
//
namespace SimpleEngine\Model;


use SimpleEngine\Controller\DatabaseController;

class Comment
{
    private static $instance; 	// ссылка на экземпляр класса
    private $msql; 				// драйвер БД

    //
    // Получение единственного экземпляра (одиночка)
    //
    public static function instance()
    {
        if (self::$instance == null)
            self::$instance = new Comment();

        return self::$instance;
    }

    //
    // Конструктор
    //
    private function __construct()
    {
        $this->msql = DatabaseController::connection();
    }

    //
    // Список всех коментариев
    //
    public function allComments($article_id)
    {
        $query = "SELECT * 
				  FROM comment 
				  WHERE article_id=$article_id ORDER BY id_comment DESC";

        return $this->msql->queryFetchAllAssoc($query);
    }

    //
    // Добавить коментарий
    //
    public function Add($article_id,$user_name, $content)
    {

        // Подготовка.
        $user_name = trim($user_name);
        $content = trim($content);

        // Проверка.
        if ($user_name == '' or $content=='')
            return false;

        // Запрос.
        $obj = array();
        $obj['article_id'] = $article_id;
        $obj['user'] = $user_name;
        $obj['text'] = $content;
        $obj['date'] = date('d.m.Y');
        print_r($obj);
        $this->msql->Insert('comments', $obj);
        return true;

    }


}
