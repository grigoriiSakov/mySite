<?php
/**
 * Created by PhpStorm.
 * User: apryakhin
 * Date: 06.06.2016
 * Time: 15:50
 */

namespace SimpleEngine\Model;


use SimpleEngine\Controller\DatabaseController;

class Page
{
    private static $instance; 	// ссылка на экземпляр класса
    private $msql; 				// драйвер БД

    //
    // Получение единственного экземпляра (одиночка)
    //
    public static function instance()
    {
        if (self::$instance == null)
            self::$instance = new Page();

        return self::$instance;
    }

    //
    // Конструктор
    //
    private function __construct()
    {
        $this->msql = DatabaseController::connection();
    }

    //
    // Список всех статей
    //
    public function allPage()
    {
        $query = "SELECT * 
				  FROM article 
				  ORDER BY id_article DESC";

        return $this->msql ->queryFetchAllAssoc($query);
    }

    //
    // Конкретная статья
    //
    public function getPage($id_article)
    {
        // Запрос.
        $t = "SELECT * 
			  FROM article 
			  WHERE id_article = '%d'";

        $query = sprintf($t, $id_article);
        $result = $this->msql->queryFetchRowAssoc($query);
        return $result;
    }

    //
    // Добавить статью
    //
    public function addPage($title, $content)
    {
        // Подготовка.
        $title = trim($title);
        $content = trim($content);

        // Проверка.
        if ($title == '')
            return false;

        // Запрос.
        $obj = array();
        $obj['title'] = $title;
        $obj['content'] = $content;

        $this->msql->Insert('articles', $obj);
        return true;
    }

    //
    // Изменить статью
    //
    public function editPage($id_article, $title, $content)
    {
        // Подготовка.
        $title = trim($title);
        $content = trim($content);

        // Проверка.
        if ($title == '')
            return false;

        // Запрос.
        $obj = array();
        $obj['title'] = $title;
        $obj['content'] = $content;

        $t = "id_article = '%d'";
        $where = sprintf($t, $id_article);
        $this->msql->Update('articles', $obj, $where);
        return true;
    }

    //
    // Удалить статью
    //
    public function deletePage($id_article)
    {
        // Запрос.
        $t = "id_article = '%d'";
        $where = sprintf($t, $id_article);
        $this->msql->Delete('articles', $where);
        return true;
    }

    // Короткое описание статьи
//
    static  public  function articlesIntro($article, $col)
    {
        return  mb_substr($article['content'], 0, $col, 'UTF-8') . '...';

    }
}