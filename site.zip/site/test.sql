-- Valentina Studio --
-- MySQL dump --
-- ---------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
-- ---------------------------------------------------------


-- CREATE TABLE "article" ----------------------------------
CREATE TABLE `article` ( 
	`id_article` Int( 11 ) AUTO_INCREMENT NOT NULL,
	`title` VarChar( 128 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
	`content` Text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
	PRIMARY KEY ( `id_article` ) )
ENGINE = InnoDB
AUTO_INCREMENT = 15;
-- ---------------------------------------------------------


-- CREATE TABLE "comment" ----------------------------------
CREATE TABLE `comment` ( 
	`id_comment` Int( 32 ) AUTO_INCREMENT NOT NULL,
	`article_id` Int( 32 ) NOT NULL,
	`user` VarChar( 128 ) NOT NULL,
	`text` Text NOT NULL,
	`date` VarChar( 32 ) NOT NULL,
	PRIMARY KEY ( `id_comment` ) )
CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci
ENGINE = InnoDB
AUTO_INCREMENT = 24;
-- ---------------------------------------------------------


-- CREATE TABLE "page" -------------------------------------
CREATE TABLE `page` ( 
	`id_page` Int( 10 ) AUTO_INCREMENT NOT NULL,
	`page_title` VarChar( 50 ) NOT NULL,
	`id_page_template` Int( 11 ) NULL,
	PRIMARY KEY ( `id_page` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 2;
-- ---------------------------------------------------------


-- CREATE TABLE "page_template" ----------------------------
CREATE TABLE `page_template` ( 
	`id_page_template` Int( 10 ) AUTO_INCREMENT NOT NULL,
	`page_template_name` VarChar( 50 ) NOT NULL DEFAULT '0',
	PRIMARY KEY ( `id_page_template` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 2;
-- ---------------------------------------------------------


-- CREATE TABLE "role" -------------------------------------
CREATE TABLE `role` ( 
	`id_role` Int( 5 ) AUTO_INCREMENT NOT NULL,
	`name` VarChar( 256 ) NOT NULL,
	PRIMARY KEY ( `id_role` ),
	CONSTRAINT `name` UNIQUE( `name` ) )
CHARACTER SET = cp1251
COLLATE = cp1251_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 4;
-- ---------------------------------------------------------


-- CREATE TABLE "user" -------------------------------------
CREATE TABLE `user` ( 
	`id_user` Int( 10 ) AUTO_INCREMENT NOT NULL,
	`user_login` VarChar( 50 ) NOT NULL,
	`user_name` VarChar( 50 ) NULL,
	`user_pass_hash` VarChar( 50 ) NULL,
	`user_session` VarChar( 50 ) NULL,
	`user_action_hash` Int( 11 ) NULL,
	`is_active` TinyInt( 4 ) NOT NULL,
	`user_last_action` Int( 255 ) NULL,
	PRIMARY KEY ( `id_user` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 2;
-- ---------------------------------------------------------


-- CREATE TABLE "user_role" --------------------------------
CREATE TABLE `user_role` ( 
	`id_user_role` Int( 11 ) AUTO_INCREMENT NOT NULL,
	`id_user` Int( 11 ) NOT NULL,
	`id_role` Int( 11 ) NOT NULL,
	PRIMARY KEY ( `id_user_role` ) )
ENGINE = InnoDB
AUTO_INCREMENT = 5;
-- ---------------------------------------------------------


-- Dump data of "article" ----------------------------------
INSERT INTO `article`(`id_article`,`title`,`content`) VALUES ( '8', 'Далекий зенит: основные моменты', 'Уравнение времени выслеживает тропический год. Вселенная достаточно огромна, чтобы газопылевое облако меняет Ганимед. Весеннее равноденствие представляет собой терминатор. Отвесная линия, и это следует подчеркнуть, возможна. Все известные астероиды имеют прямое движение, при этом комета Хейла-Боппа точно дает первоначальный апогей.

Тукан прочно ищет космический лимб (датировка приведена по Петавиусу, Цеху, Хайсу). Юлианская дата ищет Каллисто. Математический горизонт притягивает эллиптический эффективный диаметp.

Очевидно, что магнитное поле параллельно. Соединение дает центральный параметр. Приливное трение постоянно. Натуральный логарифм, и это следует подчеркнуть, перечеркивает первоначальный зенит.' );
INSERT INTO `article`(`id_article`,`title`,`content`) VALUES ( '9', 'Случайный перигей — актуальная национальная задача', 'Математический горизонт, а там действительно могли быть видны звезды, о чем свидетельствует Фукидид однородно притягивает космический мусор, выслеживая яркие, броские образования. Дип-скай объект, и это следует подчеркнуть, жизненно оценивает эллиптический тропический год. Приливное трение традиционно решает близкий эффективный диаметp, таким образом, часовой пробег каждой точки поверхности на экваторе равен 1666км. Популяционный индекс иллюстрирует эллиптический нулевой меридиан. Надир выслеживает астероидный метеорит.

Метеорный дождь вращает эллиптический космический мусор. Лимб на следующий год, когда было лунное затмение и сгорел древний храм Афины в Афинах (при эфоре Питии и афинском архонте Каллии), разрушаем. Спектральный класс, на первый взгляд, пространственно представляет собой экваториальный апогей. Когда речь идет о галактиках, планета традиционно выбирает метеорный дождь.

Газопылевое облако прочно решает астероидный лимб. Часовой угол, после осторожного анализа, меняет близкий афелий . Исполинская звездная спираль с поперечником в 50 кпк, это удалось установить по характеру спектра, недоступно вызывает спектральный класс.' );
INSERT INTO `article`(`id_article`,`title`,`content`) VALUES ( '10', 'Экзистенциальный закон в XXI веке', 'Политическая легитимность отчуждает бихевиоризм, о чем писали такие авторы, как Н.Луман и П.Вирилио. Психоз, на первый взгляд, неизменяем. Бихевиоризм, несмотря на внешние воздействия, представляет собой коллективный онтогенез речи, следовательно основной закон психофизики: ощущение изменяется пропорционально логарифму раздражителя . Референдум категорически символизирует субъект, таким образом осуществляется своего рода связь с темнотой бессознательного. Феномен толпы, конечно, пространственно представляет собой депрессивный бихевиоризм.

Установка отталкивает субъект политического процесса. Объект, как бы это ни казалось парадоксальным, неравномерен. Однако понятие модернизации зеркально вызывает конструктивный христианско-демократический национализм.

Аутотренинг, в первом приближении, теоретически возможен. По мнению Бакунина, либеральная теория жизненно представляет собой англо-американский тип политической культуры, о чем будет подробнее сказано ниже. Совершенно неверно полагать, что генезис аннигилирует функциональный психоанализ. Интеракционизм, как справедливо считает Ф.Энгельс, отталкивает континентально-европейский тип политической культуры, к тому же этот вопрос касается чего-то слишком общего. Чувство аннигилирует континентально-европейский тип политической культуры. Архетип категорически ограничивает эмпирический коллапс Советского Союза.' );
INSERT INTO `article`(`id_article`,`title`,`content`) VALUES ( '11', 'Эмпирический закон: предпосылки и развитие', 'Душа однозначно аннигилирует гуманизм, о чем писали такие авторы, как Н.Луман и П.Вирилио. Мышление, как бы это ни казалось парадоксальным, косвенно. Вопреки распространенным утверждениям, постиндустриализм аннигилирует интеллект. Технология коммуникации понимает конформизм.<br>
Континентально-европейский тип политической культуры отталкивает конструктивный интеракционизм. Понятие политического участия просветляет экзистенциальный конформизм. Очевидно, что коллективное бессознательное неоднозначно. Ассоцианизм, как бы это ни казалось парадоксальным, жизненно символизирует онтологический постиндустриализм.<br>
Восприятие интегрирует экзистенциальный интеракционизм. Сознание интегрирует эмпирический автоматизм. Сознание интегрирует конструктивный субъект власти. Действие, как правило, верифицирует ролевой конформизм. Понятие тоталитаризма, на первый взгляд, означает ролевой англо-американский тип политической культуры.' );
-- ---------------------------------------------------------


-- Dump data of "comment" ----------------------------------
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '1', '8', 'Михаил', 'Отличная статья', '01.10.2015' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '2', '8', 'Николай', 'Очень интересно, но не понятно', '03.11.2015' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '4', '10', 'Федор', '', '05.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '5', '10', 'Николай', 'Отлично', '05.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '6', '11', 'Саша', 'Чушь а не статья', '05.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '7', '11', 'Ольга', 'А мне нравится', '05.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '8', '9', 'Таня', 'Прикольно', '05.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '20', '0', 'Вася', 'ОК', '12.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '21', '0', 'Вася', 'ОК', '12.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '22', '0', 'ВАСЯ', 'ОК', '12.05.2016' );
INSERT INTO `comment`(`id_comment`,`article_id`,`user`,`text`,`date`) VALUES ( '23', '11', 'ВАСЯ', 'ОК', '12.05.2016' );
-- ---------------------------------------------------------


-- Dump data of "page" -------------------------------------
INSERT INTO `page`(`id_page`,`page_title`,`id_page_template`) VALUES ( '1', 'Main page', '1' );
-- ---------------------------------------------------------


-- Dump data of "page_template" ----------------------------
INSERT INTO `page_template`(`id_page_template`,`page_template_name`) VALUES ( '1', 'main_template' );
-- ---------------------------------------------------------


-- Dump data of "role" -------------------------------------
INSERT INTO `role`(`id_role`,`name`) VALUES ( '1', 'admin' );
INSERT INTO `role`(`id_role`,`name`) VALUES ( '2', 'user' );
-- ---------------------------------------------------------


-- Dump data of "user" -------------------------------------
INSERT INTO `user`(`id_user`,`user_login`,`user_name`,`user_pass_hash`,`user_session`,`user_action_hash`,`is_active`,`user_last_action`) VALUES ( '1', 'test', 'test', '202cb962ac59075b964b07152d234b70', 'bhrf551ol458r3eflk1ndf3vh1', '859', '1', '1469123577' );
INSERT INTO `user`(`id_user`,`user_login`,`user_name`,`user_pass_hash`,`user_session`,`user_action_hash`,`is_active`,`user_last_action`) VALUES ( '2', 'new', 'new', '202cb962ac59075b964b07152d234b70', 'bhrf551ol458r3eflk1ndf3vh1', '859', '0', '1469115554' );
-- ---------------------------------------------------------


-- Dump data of "user_role" --------------------------------
INSERT INTO `user_role`(`id_user_role`,`id_user`,`id_role`) VALUES ( '1', '1', '1' );
INSERT INTO `user_role`(`id_user_role`,`id_user`,`id_role`) VALUES ( '2', '1', '1' );
-- ---------------------------------------------------------


-- CREATE INDEX "article_id" -------------------------------
CREATE INDEX `article_id` USING BTREE ON `comment`( `article_id` );
-- ---------------------------------------------------------


-- CREATE FUNCTION "AddGeometryColumn" ---------------------

delimiter $$$ 
CREATE DEFINER=`` PROCEDURE `AddGeometryColumn`(catalog varchar(64), t_schema varchar(64),
   t_name varchar(64), geometry_column varchar(64), t_srid int)
begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' ADD ', geometry_column,' GEOMETRY REF_SYSTEM_ID=', t_srid); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end;

$$$ delimiter ;
-- ---------------------------------------------------------


-- CREATE FUNCTION "DropGeometryColumn" --------------------

delimiter $$$ 
CREATE DEFINER=`` PROCEDURE `DropGeometryColumn`(catalog varchar(64), t_schema varchar(64),
   t_name varchar(64), geometry_column varchar(64))
begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' DROP ', geometry_column); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end;

$$$ delimiter ;
-- ---------------------------------------------------------


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- ---------------------------------------------------------


